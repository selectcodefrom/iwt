<?php
include('connect.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the event ID, response, and user details from the form submission
    // Validate and sanitize inputs
$newsId = isset($_POST['newsId']) ? (int)$_POST['newsId'] : 0;
$comment = isset($_POST['comment']) ? htmlspecialchars($_POST['comment']) : '';
$userId = isset($_POST['userId']) ? (int)$_POST['userId'] : 0;
$userName = isset($_POST['userName']) ? htmlspecialchars($_POST['userName']) : '';

// Check if any of the required values is missing
if ($newsId === 0 || empty($comment) || $userId === 0 || empty($userName)) {
    echo "Invalid or missing input data.";
    exit();
}

// Now, proceed with your database operations...


    // Now, store the response and user details in a new table, e.g., event_responses
    $insertResponseQuery = $conn->prepare("INSERT INTO comments (news_id, user_id, user_name, comment) VALUES (?, ?, ?, ?)");
    $insertResponseQuery->bind_param("iiss", $newsId, $userId, $userName, $comment);

    if ($insertResponseQuery->execute()) {
        echo "<script>alert('Comment submitted successfully!'); window.location='dashboard.php';</script>";
    } else {
        echo "Error storing comment: " . $insertResponseQuery->error;
    }

    // Close the insert response prepared statement
    $insertResponseQuery->close();

    // Close the database connection
    $conn->close();
    exit();
}

// Handle invalid requests
echo "Invalid request.";

// Close the database connection
$conn->close();
?>
