<?php
session_start();

// Include database connection file
include('connect.php');

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

// Get user details
$user_id = $_SESSION['user_id'];
$username = $_SESSION['user_name'];

// Retrieve user's connections
$connectionsQuery = $conn->prepare("SELECT connection_id FROM connections WHERE user_id = ?");
$connectionsQuery->bind_param("i", $user_id);
$connectionsQuery->execute();
$connectionsResult = $connectionsQuery->get_result();
$connections = [$user_id];

while ($row = $connectionsResult->fetch_assoc()) {
    $connections[] = $row['connection_id'];
}

// Retrieve posts from user and connections
$postsQuery = $conn->prepare("SELECT posts.id, posts.content, posts.created_at, alumni.name FROM posts JOIN alumni ON posts.user_id = alumni.id WHERE posts.user_id IN (?, " . implode(", ", $connections) . ") ORDER BY posts.created_at DESC");
$postsQuery->bind_param("i", $user_id);
$postsQuery->execute();
$postsResult = $postsQuery->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Alumni Dashboard</title>
    <!-- Add your CSS and other head content here -->
</head>
<body>
    <div class="container">
        <h2>Welcome to the Alumni Dashboard, <?php echo $username; ?>!</h2>
        <a href="logout.php" class="logout-btn">Logout</a>
        <!-- Post form -->
        <form method="post" action="create_post.php">
            <textarea name="post_content" placeholder="What's on your mind?"></textarea>
            <button type="submit">Post</button>
        </form>

        <!-- Below the "Send Message Form" -->
<h3>Private Messages</h3>
<?php
$receivedMessagesQuery = $conn->prepare("SELECT * FROM messages WHERE receiver_id = ? ORDER BY sent_at DESC");
$receivedMessagesQuery->bind_param("i", $user_id);
$receivedMessagesQuery->execute();
$receivedMessagesResult = $receivedMessagesQuery->get_result();

while ($receivedMessage = $receivedMessagesResult->fetch_assoc()) {
    $senderUsername = getUsernameById($receivedMessage['sender_id']); // You need to implement this function
    echo "<div>{$senderUsername}: {$receivedMessage['message']}</div>";
}

$receivedMessagesQuery->close();
?>


        <form method="post" action="send_message.php">

    <select name="receiver_id" required>
        <option value="" disabled selected>Select a recipient</option>
        <?php
        // Fetch alumni users
        $alumniQuery = $conn->query("SELECT id, name FROM alumni WHERE id != $user_id");
        while ($alumni = $alumniQuery->fetch_assoc()) {
            echo "<option value='{$alumni['id']}'>{$alumni['name']}</option>";
        }
        ?>
    </select>
    <textarea name="message" placeholder="Type your message" required></textarea>
    <button type="submit">Send Message</button>
</form>
        <!-- Display posts -->
        <?php while ($post = $postsResult->fetch_assoc()): ?>
            <div class="post">
                <p><?php echo $post['content']; ?></p>
                <small>Posted by <?php echo $post['name']; ?> on <?php echo $post['created_at']; ?></small>
                <a href="view_profile.php?user_id=<?php echo $user['id']; ?>">View Profile</a>
            </div>
        <?php endwhile; ?>

        <a href="logout.php" class="logout-btn">Logout</a>
    </div>
</body>
</html>
