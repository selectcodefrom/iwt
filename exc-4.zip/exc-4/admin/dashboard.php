<?php
// Start the session
session_start();

// Include database connection file
include('connect.php');

// Check if the user is logged in
if (!isset($_SESSION['admin_id'])) {
    // If not logged in, redirect to the login page
    header("Location: index.php");
    exit();
}

// Folder to store uploaded files
$uploadFolder = 'uploads/';

// Function to add news and associated files
function addNews($newsName, $newsContent, $newsDate, $files) {
    global $conn, $uploadFolder;

    // Escape user inputs to prevent SQL injection
    $escapedNewsName = mysqli_real_escape_string($conn, $newsName);
    $escapedNewsContent = mysqli_real_escape_string($conn, $newsContent);
    $escapedNewsDate = mysqli_real_escape_string($conn, $newsDate);

    // Insert news details into 'news' table
    $newsInsertQuery = "INSERT INTO news (name, content, date) VALUES ('$escapedNewsName', '$escapedNewsContent', '$escapedNewsDate')";
    $conn->query($newsInsertQuery);

    // Check for errors
    if ($conn->error) {
        echo "Error inserting news: " . $conn->error;
        return;
    }

    $newsId = $conn->insert_id;

    // Allowable image file extensions
    $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif'];

    // Move files to the uploads folder and insert file details into 'files' table
    foreach ($files['name'] as $key => $fileName) {
        $filePath = $uploadFolder . $fileName;
        $fileTmpName = $files['tmp_name'][$key];
        $fileExtension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));

        // Check if the file is an image by checking its extension
        if (in_array($fileExtension, $allowedExtensions) && getimagesize($fileTmpName) !== false) {
            // It's an image
            // Move the uploaded file to the uploads folder
            if (move_uploaded_file($fileTmpName, $filePath)) {
                // Insert file details into 'files' table
                $fileInsertQuery = "INSERT INTO files (newsId, fileName, filePath) VALUES ($newsId, '$fileName', '$filePath')";
                $conn->query($fileInsertQuery);

                // Check for errors
                if ($conn->error) {
                    echo "Error inserting file details: " . $conn->error;
                    return;
                }
                
                // Redirect to the dashboard after adding news and files
                header("Location: dashboard.php");
            } else {
                // Handle error moving file
                echo "<script>alert('File move failed. Check permissions and paths.'); window.location='dashboard.php';</script>";
            }
        } else {
            // Not an allowed image format, handle accordingly
            echo "<script>alert('Invalid file type. Only images (JPG, JPEG, PNG, GIF) are allowed.'); window.location='dashboard.php';</script>";
        }
    }
}

// Get news details from the HTML form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get news details from the HTML form
    $newsName = $_POST['newsName'];
    $newsContent = $_POST['newsContent'];
    $newsDate = $_POST['newsDate'];

    // Retrieve and process uploaded files
    $files = $_FILES['files'];

    // Add news and associated files
    addNews($newsName, $newsContent, $newsDate, $files);

    // Close the database connection
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- ... (head content) -->
</head>
<body>
    <div class="container">
        <h2>Welcome to the Dashboard, <?php echo $_SESSION['user_name']; ?>!</h2>
        
        <!-- Add your dashboard content here -->

        <a href="logout.php" class="logout-btn">Logout</a>
        <h2>Create News</h2>
<form action="dashboard.php" method="post" enctype="multipart/form-data">
    <label for="newsName">News Name:</label>
    <input type="text" id="newsName" name="newsName" required />
    
    <label for="newsContent">News Content:</label>
    <textarea id="newsContent" name="newsContent" required></textarea>
    
    <label for="newsDate">News Date:</label>
    <input type="date" id="newsDate" name="newsDate" required />
    
    <label for="fileInput">Upload File:</label>
    <input type="file" id="fileInput" name="files[]" multiple />
    
    <button type="submit">Submit</button>
</form>
    </div>
</body>
</html>

<?php
// Retrieve news in descending order based on news date
$newsQuery = "SELECT * FROM news ORDER BY date DESC";
$newsResult = $conn->query($newsQuery);

// Display news
while ($news = $newsResult->fetch_assoc()) {
    echo "News Name: " . $news['name'] . "<br>";
    echo "News Content: " . $news['content'] . "<br>";
    echo "News Date: " . $news['date'] . "<br>";

    // Retrieve and display associated files
    $newsId = $news['id'];
    
    // Use prepared statement for improved security
    $filesQuery = $conn->prepare("SELECT * FROM files WHERE newsId = ?");
    $filesQuery->bind_param("i", $newsId);
    $filesQuery->execute();
    $filesResult = $filesQuery->get_result();

    if ($filesResult === false) {
        // Handle errors with the files query
        echo "Error fetching files: " . $filesQuery->error . "<br>";
    } else {
        // Check if there are files associated with the news
        if ($filesResult->num_rows > 0) {
            while ($file = $filesResult->fetch_assoc()) {
                echo "File Name: " . $file['fileName'] . "<br>";
                echo ' <img src="' . $file['filePath'] . '" alt="img" width=100 height= 100> <br><br>';
            }
        } else {
            echo "No files associated with this news.<br><br>";
        }

        // Free the result set
        $filesResult->free_result();
    }

    echo '<h2>Comments:</h2>';
    // Retrieve and display associated responses for each event
    $responsesQuery = $conn->prepare("SELECT * FROM comments WHERE news_id = ?");
    $responsesQuery->bind_param("i", $newsId);
    $responsesQuery->execute();
    $responsesResult = $responsesQuery->get_result();

    if ($responsesResult === false) {
        // Handle errors with the responses query
        echo "Error fetching responses: " . $responsesQuery->error . "<br>";
    } else {
        // Check if there are responses associated with the event
        if ($responsesResult->num_rows > 0) {
            while ($response = $responsesResult->fetch_assoc()) {
                echo "User Name: " . $response['user_name'] . "<br>";
                echo "comments: " . $response['comment'] . "<br><br>";
            }
        } else {
            echo "No comments .<br><br>";
        }

        // Free the result set
        $responsesResult->free_result();
    }

    echo '<form method="post" action="delete_news.php">';
    echo '<input type="hidden" name="newsId" value="' . $newsId . '">';
    echo '<input type="submit" value="Delete">';
    echo '</form>';

    
    
    echo "--------------------------------------------<br>";
}

// Check for errors in the news query
if ($newsResult === false) {
    echo "Error fetching news: " . $conn->error . "<br>";
}

// Close the database connection
$conn->close();
?>
