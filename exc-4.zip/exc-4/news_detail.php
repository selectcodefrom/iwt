<?php
include('connect.php');

// Retrieve news details based on the news_id parameter in the URL
$newsId = isset($_GET['news_id']) ? (int)$_GET['news_id'] : 0;

if ($newsId > 0) {
    // Retrieve news details
    $newsQuery = $conn->prepare("SELECT * FROM news WHERE id = ?");
    $newsQuery->bind_param("i", $newsId);
    $newsQuery->execute();
    $newsResult = $newsQuery->get_result();

    if ($newsResult->num_rows > 0) {
        $news = $newsResult->fetch_assoc();
        // Display news details
        echo "<h1>{$news['name']}</h1>";
        echo "<p>{$news['content']}</p>";
        echo "<p>Date: {$news['date']}</p>";

        // Retrieve and display associated images
        $imagesQuery = $conn->prepare("SELECT * FROM files WHERE newsId = ?");
        $imagesQuery->bind_param("i", $newsId);
        $imagesQuery->execute();
        $imagesResult = $imagesQuery->get_result();

        if ($imagesResult->num_rows > 0) {
            echo "<h2>Images</h2>";
            while ($image = $imagesResult->fetch_assoc()) {
                echo "<img src='admin/{$image['filePath']}' alt='Image'>";
            }
        }

        $imagesQuery->close();
        echo '<h2>Comments:</h2>';
    // Retrieve and display associated responses for each event
    $responsesQuery = $conn->prepare("SELECT * FROM comments WHERE news_id = ?");
    $responsesQuery->bind_param("i", $newsId);
    $responsesQuery->execute();
    $responsesResult = $responsesQuery->get_result();

    if ($responsesResult === false) {
        // Handle errors with the responses query
        echo "Error fetching comments: " . $responsesQuery->error . "<br>";
    } else {
        // Check if there are responses associated with the event
        if ($responsesResult->num_rows > 0) {
            while ($response = $responsesResult->fetch_assoc()) {
                echo "User Name: " . $response['user_name'] . "<br>";
                echo "comments: " . $response['comment'] . "<br><br>";
            }
        } else {
            echo "No comments .<br><br>";
        }

        // Free the result set
        $responsesResult->free_result();
    }
    } else {
        echo "News not found.";
    }

    $newsQuery->close();
} else {
    echo "Invalid news ID.";
}

$conn->close();
?>
