<?php
$host = 'localhost';
$db   = 'alumini_db';
$user = 'root';
$pass = '';

// Create database connection
$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>