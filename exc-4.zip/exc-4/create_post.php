<?php
session_start();

// Include database connection file
include('connect.php');

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

// Get user details
$user_id = $_SESSION['user_id'];

// Get post content
$post_content = $_POST['post_content'];

// Insert post into the database
$insertPostQuery = $conn->prepare("INSERT INTO posts (user_id, content) VALUES (?, ?)");
$insertPostQuery->bind_param("is", $user_id, $post_content);

if ($insertPostQuery->execute()) {
    header("Location: dashboard.php");
} else {
    echo "Error creating post: " . $conn->error;
}

// Close the insert post prepared statement
$insertPostQuery->close();

// Close the database connection
$conn->close();
?>
