<?php
session_start();
include('connect.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sender_id = $_SESSION['user_id'];
    $receiver_id = $_POST['receiver_id'];
    $message = mysqli_real_escape_string($conn, $_POST['message']);

    $insertMessageQuery = $conn->prepare("INSERT INTO messages (sender_id, receiver_id, message) VALUES (?, ?, ?)");
    $insertMessageQuery->bind_param("iis", $sender_id, $receiver_id, $message);

    if ($insertMessageQuery->execute()) {
        echo "<script>alert('Message sent successfully!'); window.location='dashboard.php';</script>";
    } else {
        echo "Error sending message: " . $insertMessageQuery->error;
    }

    $insertMessageQuery->close();
    $conn->close();
    exit();
}

echo "Invalid request.";
$conn->close();
?>
