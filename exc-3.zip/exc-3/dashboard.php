<?php
// Start the session
session_start();

// Include database connection file
include('connect.php');

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    // If not logged in, redirect to the login page
    header("Location: index.php");
    exit();
}

// Folder to store uploaded files
$uploadFolder = 'uploads/';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- ... (head content) -->
</head>
<body>
    <div class="container">
        <h2>Welcome to the Dashboard, <?php echo $_SESSION['user_name']; ?>!</h2>
        
        <!-- Add your dashboard content here -->

        <a href="logout.php" class="logout-btn">Logout</a>
        
    </div>
    <script>
document.addEventListener('DOMContentLoaded', function () {
    // Find all elements with the class 'copy-link-btn'
    var copyLinkButtons = document.querySelectorAll('.copy-link-btn');

    // Attach click event listener to each button
    copyLinkButtons.forEach(function (button) {
        button.addEventListener('click', function () {
            // Get the data-link attribute value
            var linkToCopy = button.getAttribute('data-link');

            // Create a temporary input element
            var tempInput = document.createElement('input');
            tempInput.value = linkToCopy;

            // Append the input element to the DOM
            document.body.appendChild(tempInput);

            // Select the text in the input element
            tempInput.select();
            tempInput.setSelectionRange(0, 99999); // For mobile devices

            // Copy the selected text to the clipboard
            document.execCommand('copy');

            // Remove the temporary input element
            document.body.removeChild(tempInput);

            // Provide some feedback to the user (optional)
            alert('Link copied to clipboard: ' + linkToCopy);
        });
    });
});
</script>

</body>
</html>

<?php
// Retrieve news in descending order based on news date
$newsQuery = "SELECT * FROM news ORDER BY date DESC";
$newsResult = $conn->query($newsQuery);

// Display news
while ($news = $newsResult->fetch_assoc()) {
    echo "News Name: " . $news['name'] . "<br>";
    echo "News Content: " . $news['content'] . "<br>";
    echo "News Date: " . $news['date'] . "<br>";

    // Retrieve and display associated files
    $newsId = $news['id'];
    
    // Use prepared statement for improved security
    $filesQuery = $conn->prepare("SELECT * FROM files WHERE newsId = ?");
    $filesQuery->bind_param("i", $newsId);
    $filesQuery->execute();
    $filesResult = $filesQuery->get_result();

    if ($filesResult === false) {
        // Handle errors with the files query
        echo "Error fetching files: " . $filesQuery->error . "<br>";
    } else {
        // Check if there are files associated with the news
        if ($filesResult->num_rows > 0) {
            while ($file = $filesResult->fetch_assoc()) {
                echo ' <img src="admin/' . $file['filePath'] . '" alt="img" width=100 height= 100> <br><br>';
            }
        } else {
            echo "No files associated with this news.<br><br>";
        }

        // Free the result set
        $filesResult->free_result();
    }

    echo '<form class="response-form" method="post" action="comment.php">';
    echo '<input type="hidden" name="newsId" value="' . $newsId . '">';
    echo 'Add Comment: <input type="text" name="comment" required>';
    
    // Include user details (assuming you have user_id and user_name in the session)
    echo '<input type="hidden" name="userId" value="' . $_SESSION['user_id'] . '">';
    echo '<input type="hidden" name="userName" value="' . $_SESSION['user_name'] . '">';
    
    echo '<input type="submit" value="Submit">';
    echo '</form>';


    $detailLink = "news_detail.php?news_id={$news['id']}";
    echo "<a href='{$detailLink}'>Read More</a>";
    echo "<button class='copy-link-btn' data-link='{$detailLink}'>Copy Link</button>";

    echo '<h2>Comments:</h2>';
    // Retrieve and display associated responses for each event
    $responsesQuery = $conn->prepare("SELECT * FROM comments WHERE news_id = ?");
    $responsesQuery->bind_param("i", $newsId);
    $responsesQuery->execute();
    $responsesResult = $responsesQuery->get_result();

    if ($responsesResult === false) {
        // Handle errors with the responses query
        echo "Error fetching comments: " . $responsesQuery->error . "<br>";
    } else {
        // Check if there are responses associated with the event
        if ($responsesResult->num_rows > 0) {
            while ($response = $responsesResult->fetch_assoc()) {
                echo "User Name: " . $response['user_name'] . "<br>";
                echo "comments: " . $response['comment'] . "<br><br>";
            }
        } else {
            echo "No comments .<br><br>";
        }

        // Free the result set
        $responsesResult->free_result();
    }
    echo "--------------------------------------------<br>";
}

// Check for errors in the news query
if ($newsResult === false) {
    echo "Error fetching news: " . $conn->error . "<br>";
}

// Close the database connection
$conn->close();
?>
