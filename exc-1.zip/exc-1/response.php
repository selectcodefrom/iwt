<?php
include('connect.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the event ID, response, and user details from the form submission
    $eventId = $_POST['eventId'];
    $response = $_POST['response'];
    $userId = $_POST['userId'];
    $userName = $_POST['userName'];

    // Now, store the response and user details in a new table, e.g., event_responses
    $insertResponseQuery = $conn->prepare("INSERT INTO event_responses (event_id, user_id, user_name, response) VALUES (?, ?, ?, ?)");
    $insertResponseQuery->bind_param("iiss", $eventId, $userId, $userName, $response);

    if ($insertResponseQuery->execute()) {
        echo "<script>alert('Response submitted successfully!'); window.location='dashboard.php';</script>";
    } else {
        echo "Error storing response: " . $insertResponseQuery->error;
    }

    // Close the insert response prepared statement
    $insertResponseQuery->close();

    // Close the database connection
    $conn->close();
    exit();
}

// Handle invalid requests
echo "Invalid request.";

// Close the database connection
$conn->close();
?>
