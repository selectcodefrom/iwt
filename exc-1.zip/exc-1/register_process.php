<?php

include('connect.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $name = $_POST["name"];
    $mobileNumber = $_POST["mobile_number"];
    $email = $_POST["email"];
    $graduationYear = $_POST["graduation_year"];
    $degree = $_POST["degree"];
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT); // Hash the password
    // Insert data into the database
    $sql = "INSERT INTO alumni (name, mobile_number, email, graduation_year, degree, password) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    
    if ($stmt) {
        $stmt->bind_param("ssssss", $name, $mobileNumber, $email, $graduationYear, $degree, $password);
        $stmt->execute();

        echo "Registration successful!";
    } else {
        echo "Error: " . $conn->error;
    }

    $stmt->close();
}

// Close the database connection
$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alumni Registration</title>
    <script>
        function validateForm() {
            var mobileNumber = document.forms["registrationForm"]["mobile_number"].value;
            var email = document.forms["registrationForm"]["email"].value;
            var password = document.forms["registrationForm"]["password"].value;
            var confirmPassword = document.forms["registrationForm"]["confirm_password"].value;

            // Basic validation for name (non-empty)
           

            // Validation for mobile number (numeric, 10 digits)
            if (!/^\d{10}$/.test(mobileNumber)) {
                alert("Please enter a valid 10-digit mobile number.");
                return false;
            }

            // Validation for email format
            var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailPattern.test(email)) {
                alert("Please enter a valid email address.");
                return false;
            }

            // Validation for password (at least 6 characters)
            if (password.length < 6) {
                alert("Password must be at least 6 characters long.");
                return false;
            }

            // Validation for matching passwords
            if (password !== confirmPassword) {
                alert("Passwords do not match.");
                return false;
            }

            return true;
        }
    </script>
</head>
<body>
    <h2>Alumni Registration Form</h2>
    <form name="registrationForm" action="register_process.php" method="post" onsubmit="return validateForm()">
        <label for="name">Name:</label>
        <input type="text" name="name" required><br>

        <label for="mobile_number">Mobile Number:</label>
        <input type="text" name="mobile_number" pattern="\d{10}" required><br>

        <label for="email">Email:</label>
        <input type="email" name="email" required><br>

        <label for="graduation_year">Graduation Year:</label>
        <select name="graduation_year" required>
            <?php
            $currentYear = date("Y");
            $startYear = $currentYear - 50;
            for ($year = $currentYear; $year >= $startYear; $year--) {
                echo "<option value=\"$year\">$year</option>";
            }
            ?>
        </select><br>

        <label for="degree">Degree Earned:</label>
        <select name="degree" required>
            <option value="Bachelor">Bachelor</option>
            <option value="Master">Master</option>
            <option value="Doctorate">Doctorate</option>
            <!-- Add more options as needed -->
        </select><br>

        <label for="password">Password:</label>
        <input type="password" name="password" minlength="6" required><br>

        <label for="confirm_password">Confirm Password:</label>
        <input type="password" name="confirm_password" minlength="6" required><br>

        <input type="submit" value="Register">
    </form>
</body>
</html>

