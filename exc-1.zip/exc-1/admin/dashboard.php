<?php
// Start the session
session_start();

// Include database connection file
include('connect.php');

// Check if the user is logged in
if (!isset($_SESSION['admin_id'])) {
    // If not logged in, redirect to the login page
    header("Location: index.php");
    exit();
}

// Folder to store uploaded files
$uploadFolder = 'uploads/';

// Function to add an event and associated files
function addEvent($eventName, $eventDate, $files) {
    global $conn, $uploadFolder;

    // Insert event details into 'events' table
    $eventInsertQuery = "INSERT INTO events (eventName, eventDate) VALUES ('$eventName', '$eventDate')";
    $conn->query($eventInsertQuery);
    $eventId = $conn->insert_id;

    // Allowable image file extensions
    $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif'];

    // Move files to the uploads folder and insert file details into 'files' table
    foreach ($files['name'] as $key => $fileName) {
        $filePath = $uploadFolder . $fileName;
        $fileTmpName = $files['tmp_name'][$key];
        $fileExtension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));

        // Check if the file is an image by checking its extension
        if (in_array($fileExtension, $allowedExtensions) && getimagesize($fileTmpName) !== false) {
            // It's an image
            // Move the uploaded file to the uploads folder
            if (move_uploaded_file($fileTmpName, $filePath)) {
                // Insert file details into 'files' table
                $fileInsertQuery = "INSERT INTO files (eventId, fileName, filePath) VALUES ($eventId, '$fileName', '$filePath')";
                $conn->query($fileInsertQuery);
                header("Location: dashboard.php");
            } else {
                // Handle error moving file
                echo "<script>alert('File move failed. Check permissions and paths.'); window.location='dashboard.php';</script>";
            }
        } else {
            // Not an allowed image format, handle accordingly
            echo "<script>alert('Invalid file type. Only images (JPG, JPEG, PNG, GIF) are allowed.'); window.location='dashboard.php';</script>";
        }
    }

    // Redirect to the dashboard after adding the event and files
  
}

// Get event details from the HTML form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get event details from the HTML form
    $eventName = $_POST['eventName'];
    $eventDate = $_POST['eventDate'];

    // Retrieve and process uploaded files
    $files = $_FILES['files'];

    // Add an event and associated files
    addEvent($eventName, $eventDate, $files);

    // Close the database connection
    
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <!-- ... (head content) -->
</head>
<body>
    <div class="container">
        <h2>Welcome to the Dashboard, <?php echo $_SESSION['user_name']; ?>!</h2>
        
        <!-- Add your dashboard content here -->

        <a href="logout.php" class="logout-btn">Logout</a>
        <h2>Create Event</h2>
    <form action="dashboard.php" method="post" enctype="multipart/form-data">
        <label for="eventName">Event Name:</label>
        <input type="text" id="eventName" name="eventName" required />
        
        <label for="eventDate">Event Date:</label>
        <input type="date" id="eventDate" name="eventDate" required />
        
        <label for="fileInput">Upload File:</label>
        <input type="file" id="fileInput" name="files[]" multiple />
        
        <button type="submit">Submit</button>
    </form>
        

    </div>
</body>
</html>
<?php
// Retrieve events in descending order based on event date
$eventsQuery = "SELECT * FROM events ORDER BY date DESC";
$eventsResult = $conn->query($eventsQuery);

// Display events
while ($event = $eventsResult->fetch_assoc()) {
    echo "Event Name: " . $event['eventName'] . "<br>";
    echo "Event Date: " . $event['eventDate'] . "<br>";

    // Retrieve and display associated files
    $eventId = $event['id'];
    
    // Use prepared statement for improved security
    $filesQuery = $conn->prepare("SELECT * FROM files WHERE eventId = ?");
    $filesQuery->bind_param("i", $eventId);
    $filesQuery->execute();
    $filesResult = $filesQuery->get_result();

    if ($filesResult === false) {
        // Handle errors with the files query
        echo "Error fetching files: " . $filesQuery->error . "<br>";
    } else {
        // Check if there are files associated with the event
        if ($filesResult->num_rows > 0) {
            while ($file = $filesResult->fetch_assoc()) {
                echo "File Name: " . $file['fileName'] . "<br>";
                echo ' <img src="' . $file['filePath'] . '" alt="img" width=100 height= 100> <br><br>';
            }
        } else {
            echo "No files associated with this event.<br><br>";
        }

        // Free the result set
        $filesResult->free_result();
    }
    echo '<h2>Responses:</h2>';
    // Retrieve and display associated responses for each event
    $responsesQuery = $conn->prepare("SELECT * FROM event_responses WHERE event_id = ?");
    $responsesQuery->bind_param("i", $eventId);
    $responsesQuery->execute();
    $responsesResult = $responsesQuery->get_result();

    if ($responsesResult === false) {
        // Handle errors with the responses query
        echo "Error fetching responses: " . $responsesQuery->error . "<br>";
    } else {
        // Check if there are responses associated with the event
        if ($responsesResult->num_rows > 0) {
            while ($response = $responsesResult->fetch_assoc()) {
                echo "User Name: " . $response['user_name'] . "<br>";
                echo "Response: " . $response['response'] . "<br><br>";
            }
        } else {
            echo "No responses associated with this event.<br><br>";
        }

        // Free the result set
        $responsesResult->free_result();
    }

    echo '<form method="post" action="delete_event.php">';
    echo '<input type="hidden" name="eventId" value="' . $eventId . '">';
    echo '<input type="submit" value="Delete Event">';
    echo '</form>';
    echo "--------------------------------------------<br>";
}

// Check for errors in the events query
if ($eventsResult === false) {
    echo "Error fetching events: " . $conn->error . "<br>";
}

// Close the database connection
$conn->close();
?>





