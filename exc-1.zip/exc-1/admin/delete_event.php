<?php
include('connect.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the event ID to be deleted
    $eventId = $_POST['eventId'];

    // Use prepared statement to delete the event and its associated files
    $deleteEventQuery = $conn->prepare("DELETE FROM events WHERE id = ?");
    $deleteEventQuery->bind_param("i", $eventId);

    if ($deleteEventQuery->execute()) {
        // Event deleted successfully, now delete associated files
        $deleteFilesQuery = $conn->prepare("DELETE FROM files WHERE eventId = ?");
        $deleteFilesQuery->bind_param("i", $eventId);
        $deleteFilesQuery->execute();

        echo "Event and associated files deleted successfully!";
    } else {
        // Handle the deletion error
        echo "Error deleting event: " . $deleteEventQuery->error;
    }

    // Close the prepared statements
    $deleteEventQuery->close();
    $deleteFilesQuery->close();

    // Redirect back to the main page
    header("Location: dashboard.php");
    exit();
}

// Close the database connection
$conn->close();
?>
