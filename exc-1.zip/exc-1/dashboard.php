<?php
// Start the session
session_start();

// Include database connection file
include('connect.php');

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    // If not logged in, redirect to the login page
    header("Location: index.php");
    exit();
}

// Folder to store uploaded files
$uploadFolder = 'uploads/';


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <!-- ... (head content) -->
</head>
<body>
    <div class="container">
        <h2>Welcome to the Dashboard, <?php echo $_SESSION['user_name']; ?>!</h2>
        
        <!-- Add your dashboard content here -->

        <a href="logout.php" class="logout-btn">Logout</a>
        
        

    </div>
</body>
</html>
<?php
// Retrieve events in descending order based on event date
$eventsQuery = "SELECT * FROM events ORDER BY date DESC";
$eventsResult = $conn->query($eventsQuery);

// Display events
while ($event = $eventsResult->fetch_assoc()) {
    echo "Event Name: " . $event['eventName'] . "<br>";
    echo "Event Date: " . $event['eventDate'] . "<br>";

    // Retrieve and display associated files
    $eventId = $event['id'];
    
    // Use prepared statement for improved security
    $filesQuery = $conn->prepare("SELECT * FROM files WHERE eventId = ?");
    $filesQuery->bind_param("i", $eventId);
    $filesQuery->execute();
    $filesResult = $filesQuery->get_result();

    if ($filesResult === false) {
        // Handle errors with the files query
        echo "Error fetching files: " . $filesQuery->error . "<br>";
    } else {
        // Check if there are files associated with the event
        if ($filesResult->num_rows > 0) {
            while ($file = $filesResult->fetch_assoc()) {
                echo "File Name: " . $file['fileName'] . "<br>";
                echo ' <img src="admin/' . $file['filePath'] . '" alt="img" width=100 height= 100> <br><br>';
            }
        } else {
            echo "No files associated with this event.<br><br>";
        }

        // Free the result set
        $filesResult->free_result();
    }

    echo '<form class="response-form" method="post" action="response.php">';
    echo '<input type="hidden" name="eventId" value="' . $eventId . '">';
    echo 'Response: <input type="text" name="response" required>';
    
    // Include user details (assuming you have user_id and user_name in the session)
    echo '<input type="hidden" name="userId" value="' . $_SESSION['user_id'] . '">';
    echo '<input type="hidden" name="userName" value="' . $_SESSION['user_name'] . '">';
    
    echo '<input type="submit" value="Submit Response">';
    echo '</form>';
    echo "--------------------------------------------<br>";
}

// Check for errors in the events query
if ($eventsResult === false) {
    echo "Error fetching events: " . $conn->error . "<br>";
}

// Close the database connection
$conn->close();
?>





